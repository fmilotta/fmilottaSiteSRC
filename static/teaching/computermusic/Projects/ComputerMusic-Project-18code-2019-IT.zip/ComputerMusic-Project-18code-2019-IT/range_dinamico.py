#Misura della variazione del range dinamico nel dominio delle frequenze

import numpy as np
from scipy.io.wavfile import read
import matplotlib.pyplot as plt


#1. Leggo il file wave

file = read("guitar_loop.wav")


#2. Trasformo il file wave in array

array = np.array(file[1], dtype=float)


#3. Il File è in stereo. Considero solo un canale lavorando in mono

signal=[]

for i in range(0, (len(array)-1)):
    signal.append(array[i][0])




WINDOW = 4#Dimensione della finestra


#4. Calcolo il delta di ogni finestra



range_list=[] #array finale

i=0

while(i<len(signal)): #scorro tutto l'array

    min=signal[i]
    max=signal[i]
    for j in range(0,WINDOW): #per ogni finestra, calcolo la variazione del range



        if(signal[i+j]<min):
            min=signal[i+j]

        if(signal[i+j]>max):
            max=signal[i+j]

    delta=max-min
    range_list.append(delta) #inserimento nell'array finale

    i=i+WINDOW


print("Variazioni del range dinamico: ")
print(range_list)


x= np.arange(84000)
y=range_list
plt.plot(x,y)
plt.title("Range Dinamico della traccia 'guitar_loop.wav'")
plt.xlabel('Freq [Hz]')
plt.ylabel('Ampiezza')
plt.grid()
plt.show()
