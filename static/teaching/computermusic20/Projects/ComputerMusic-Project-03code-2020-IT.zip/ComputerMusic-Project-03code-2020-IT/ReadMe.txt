Titolo: MidiPlayer.java
Autore: Blanco Francesco Giulio
Progetto di Informatica Musicale
A.A. 2020/2021

Come mandare in esecuzione il codice:
[Da IDE (es. NetBeans/IntelliJ IDEA)]: 
1.	Crea un project "MIDI_Project"
2.	Crea un package "midi" su Source Packages
3.	Crea la classe "MidiPlayer" (nota: NON creare il main)
4.	Cancella il template fornito dall'IDE e copia e incolla il codice fornito nella classe appena creata
5.	Manda in run il codice

Output finale:
1.	Verrà eseguito il brano "Mary had a little lamb"
2.	Il brano verrà salvato sul file "midifile.mid" (nota: il file verrà creato nella directory del sorgente)
3.	Il brano può essere aperto e modificato con altri programmi di composizione musicale

Per ulteriori informazioni/chiarimenti scrivi a:
blanco.francesco@studium.unict.it