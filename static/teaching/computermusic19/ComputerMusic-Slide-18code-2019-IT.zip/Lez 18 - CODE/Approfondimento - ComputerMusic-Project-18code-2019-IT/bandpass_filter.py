#Filtro passa-banda in Python

import numpy as np
from scipy.signal import butter, freqz
import matplotlib.pyplot as plt
from scipy.signal import butter

#Funzioni scipy per filtrare il segnale

def butter_bandpass(lowcut, highcut,fs, order):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return b, a



#Parametri dei filtri

order = 15 #Ordine del filtro
fs = 30.0 #Frequenza di campionamento
#Frequenze del range del passa-banda

low = float(input("Bandpass filter - Inserisci la frequenza di taglio bassa: "))
high = float(input("Inserisci la frequenza di taglio alta: "))

#Filtraggio del segnale
b, a = butter_bandpass(low, high, fs, order)


# Plot della risposta finale

w, h = freqz(b, a)
plt.subplot(1, 1, 1)
plt.plot(0.5*fs*w/np.pi, np.abs(h), 'b')

plt.xlim(0, 0.5*fs)
plt.title("Bandpass Filter")
plt.xlabel('Freq [Hz]')
plt.grid()
plt.show()



