Autore progetto: Enrico Cosentino
AA 2018/2019 Corso di Informatica Musicale del Prof. Filippo Milotta

Progetto 04: Beat Detection
Guida all'uso:
1) Scaricare Processing da: https://processing.org/download/
2) Usarlo per aprire i file Progetto_IM.pde e MyBeatDetect.pde
3) Sostituire la stringa placeholder in Progetto_IM.pde col percorso della traccia che si vuole analizzare
4) Opzionalmente, decommentare la parte delimitata se si vuole effettuare l'analisi di "impulseTrain.wav"

Il progetto contiene:

-MyBeatDetect.pde, una classe per fare beat detection
-Progetto_IM.pde, contenente del codice d'esempio per l'uso di MyBeatDetect.pde
-impulseTrain.wav, un file audio di esempio da analizzare con MyBeatDetect
