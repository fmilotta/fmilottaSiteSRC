Autori progetto: Andronaco Marco, Campione Giacomo e Caruso Bartolomeo
AA 2018/2019 Corso di Informatica Musicale del Prof. Filippo Milotta

Progetto 05: Pure Data
Guida all�uso:
1) Scaricare Pure data da: https://puredata.info/downloads/pure-data
2) Installarlo sulla macchina
3) Aprire pd e abilitare la spunta su �DSP�
4) Aprire il tab �File�
5) Clicca su �Apri file�
6) Cerca nel computer dove scaricato i 4 progetti pd ed aprili. 

I progetti contengono:

-�basic-synth.pd� � un semplice sintetizzatore di frequenze (variabile reale)

-�midi-synth.pd� � un sintetizzatore di frequenze (a variabile naturale)

-�noise-masking.pd� � il progetto che simula il mascheramento non tonale, attenzione a settare bene le spunte per abilitare grafico e audio.

-�tonal-masking.pd� � il progetto che simula il mascheramento tonale, attenzione a settare bene le spunte per abilitare grafico e audio.
