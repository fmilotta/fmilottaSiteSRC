package midi;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiEvent;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.Track;

/**
 *
 * @author BlancoFrancescoGiulio
 */
 
public class MidiPlayer {
	
	private static final String SEQ_DEV_NAME = "default";
	private static final String SEQ_PROP_KEY = "javax.sound.midi.Sequence";

	public static void main(String[] args) {
        new MidiPlayer().run();
	}

	private void run() {
        Sequencer sequencer = getSequencer();
        if (sequencer == null) {
			return;
		}

		try {
			sequencer.open();
		} catch (MidiUnavailableException e1) {
			e1.printStackTrace();
			return;
		}

		sequencer.setTempoInBPM(164.0f);
		
		Sequence seq;
		try {
			seq = getMidiInputData();
			sequencer.setSequence(seq);
		} catch (InvalidMidiDataException e1) {
			e1.printStackTrace();
			return;
		}

		sleep(200);
		sequencer.start();

		while (sequencer.isRunning()) {
			sleep(1000);
		}
            sleep(200);
            salvaSuFile(seq);
            sequencer.close();
	}

	private Sequence getMidiInputData() {
        int ticksPerQuarterNote = 4;
        Sequence seq;
        try {
			seq = new Sequence(Sequence.PPQ, ticksPerQuarterNote);
			setMidiEvents(seq.createTrack());
		} catch (InvalidMidiDataException e) {
            e.printStackTrace();
			return null;
		}
		return seq;
	}

	private void setMidiEvents(Track track) {
        ShortMessage sm = new ShortMessage( );         
        int instrument = 26;    
        try {
            sm.setMessage(ShortMessage.PROGRAM_CHANGE, 2, instrument, 0);
        } catch (InvalidMidiDataException ex) {
            Logger.getLogger(MidiPlayer.class.getName()).log(Level.SEVERE, null, ex);
        }
		track.add(new MidiEvent(sm, 0));

		int channel = 1;
		int velocity = 64;
		int note = 60; 
		int tick = 0;
		int n=3; 
        for (int i=0; i<n; i++){
            switch(i){
				case 0:
					break;
				case 1:
					tick = 0;
					note = 60 +12;
					channel=2;
					break;
				case 2:
					tick = 0;
					note = 60;
					channel=9;
					break;
				default:
					break;
                }


        addMidiEvent(track, ShortMessage.NOTE_ON, channel, note, velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note, 0, tick);
                tick+=1;
		addMidiEvent(track, ShortMessage.NOTE_ON, channel, note - 2, velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note - 2, 0, tick);
                tick+=1;
		addMidiEvent(track, ShortMessage.NOTE_ON, channel, note - 4, velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note - 4, 0, tick );
                tick+=1;
		addMidiEvent(track, ShortMessage.NOTE_ON, channel, note - 2, velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note - 2, 0, tick);
                tick+=1;
		addMidiEvent(track, ShortMessage.NOTE_ON, channel, note, velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note, 0, tick);
                tick+=1;
		addMidiEvent(track, ShortMessage.NOTE_ON, channel, note, velocity, tick );
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note, 0, tick);
                tick+=1;
		addMidiEvent(track, ShortMessage.NOTE_ON, channel, note, velocity, tick);
                tick+=7;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note, 0, tick);
                tick+=1;

        addMidiEvent(track, ShortMessage.NOTE_ON, channel, note , velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note , 0, tick);
                tick+=1;
                addMidiEvent(track, ShortMessage.NOTE_ON, channel, note - 2, velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note - 2, 0, tick);
                tick+=1;
                addMidiEvent(track, ShortMessage.NOTE_ON, channel, note - 2, velocity, tick);
                tick+=7;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note - 2, 0, tick);
                tick+=1;

        addMidiEvent(track, ShortMessage.NOTE_ON, channel, note , velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note , 0, tick);
                tick+=1;
                addMidiEvent(track, ShortMessage.NOTE_ON, channel, note + 3, velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note + 3, 0, tick);
                tick+=1;
                addMidiEvent(track, ShortMessage.NOTE_ON, channel, note +3, velocity, tick);
                tick+=7;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note +3, 0, tick);
                tick+=1;
                
        addMidiEvent(track, ShortMessage.NOTE_ON, channel, note, velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note, 0, tick);
                tick+=1;
		addMidiEvent(track, ShortMessage.NOTE_ON, channel, note - 2, velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note - 2, 0, tick);
                tick+=1;
		addMidiEvent(track, ShortMessage.NOTE_ON, channel, note - 4, velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note - 4, 0, tick );
                tick+=1;
		addMidiEvent(track, ShortMessage.NOTE_ON, channel, note - 2, velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note - 2, 0, tick);
                tick+=1;
		addMidiEvent(track, ShortMessage.NOTE_ON, channel, note, velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note, 0, tick);
                tick+=1;
		addMidiEvent(track, ShortMessage.NOTE_ON, channel, note, velocity, tick );
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note, 0, tick);
                tick+=1;
		addMidiEvent(track, ShortMessage.NOTE_ON, channel, note, velocity, tick);
                tick+=7;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note, 0, tick);
                tick+=1;
				
        addMidiEvent(track, ShortMessage.NOTE_ON, channel, note -2 , velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note -2 , 0, tick);
                tick+=1;
                addMidiEvent(track, ShortMessage.NOTE_ON, channel, note -2 , velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note -2 , 0, tick);
                tick+=1;
                addMidiEvent(track, ShortMessage.NOTE_ON, channel, note , velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note , 0, tick);
                tick+=1;
                addMidiEvent(track, ShortMessage.NOTE_ON, channel, note -2, velocity, tick);
                tick+=3;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note - 2, 0, tick);
                tick+=1;
                addMidiEvent(track, ShortMessage.NOTE_ON, channel, note -4, velocity, tick);
                tick+=10;
		addMidiEvent(track, ShortMessage.NOTE_OFF, channel, note -4, 0, tick);
                tick+=1;
                }
	}

	private void addMidiEvent(Track track, int command, int channel, int data1,
			int data2, int tick) {
		ShortMessage message = new ShortMessage();
		try {
			message.setMessage(command, channel, data1, data2);
		} catch (InvalidMidiDataException e) {
			e.printStackTrace();
		}
		track.add(new MidiEvent(message, tick));
	}

	private Sequencer getSequencer() {
		if (!SEQ_DEV_NAME.isEmpty()
				|| !"default".equalsIgnoreCase(SEQ_DEV_NAME)) {
			System.setProperty(SEQ_PROP_KEY, SEQ_DEV_NAME);
		}

		try {
			return MidiSystem.getSequencer();
		} catch (MidiUnavailableException e) {
			System.err.println("Error getting sequencer");
			e.printStackTrace();
			return null;
		}
	}

	private void sleep(long millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

    private void salvaSuFile(Sequence seq) {
		File f = new File("midifile.mid");
            try {
                MidiSystem.write(seq,1,f);
            } catch (IOException ex) {
                Logger.getLogger(MidiPlayer.class.getName()).log(Level.SEVERE, null, ex);
            }
                System.out.println("midifile end ");  
    }
}