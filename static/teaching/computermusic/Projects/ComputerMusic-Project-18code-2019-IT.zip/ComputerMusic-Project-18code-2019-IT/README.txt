Autori progetto: Baiomazzola Samuele, Bongiovanni Giusy Agata e Esposito Ferrara Chiara
AA 2018/2019 Corso di Informatica Musicale del Prof. Filippo Milotta

Progetto 18: Risposta in frequenza di segnali audio in Python
Guida all�uso:
1) Scaricare Anaconda o JetBrains PyCharm Edu
2) Aprire il tab �File�
3) Cliccare su �Apri file�
4) Cercare nel computer dove scaricato i 4 progetti pd ed aprirli

I progetti contengono:
- "lowpass_filter.py": implementazione in Python del filtro passa-basso; 
   avviando il codice, bisogner� inserire da tastiera la frequenza di taglio che si desidera utilizzare per il filtro.
- "highpass_filter.py": implementazione in Python del filtro passa-alto
   avviando il codice, bisogner� inserire da tastiera la frequenza di taglio che si desidera utilizzare per il filtro.
- "bandpass_filter.py": implementazione in Python del filtro passa-banda
   avviando il codice, bisogner� inserire da tastiera la frequenza di taglio inferiore e poi quella superiore che si desidera utilizzare per il filtro.
- "range_dinamico.py": implementazione in Python della misurazione della variazione del range dinamico
- "guitar_loop.wav": traccia audio utilizzata per il calcolo del range dinamico
