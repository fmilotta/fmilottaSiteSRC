#Filtro passa-alto in Python

import numpy as np
from scipy.signal import butter, lfilter, freqz
import matplotlib.pyplot as plt

#Funzioni scipy per filtrare il segnale

def butter_highpass(cutoff, fs, order):
    nyq = 0.5 * fs
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='high', analog=False)
    return b, a



#Parametri dei filtri

order = 15 #Ordine del filtro
fs = 30.0 #Frequenza di campionamento

cutoff = float(input("Highpass filter - Inserisci la frequenza di taglio: "))  #Frequenza di taglio desiderata

#Filtraggio del segnale
b, a = butter_highpass(cutoff, fs, order)



#Plot della riposta finale

w, h = freqz(b, a)
plt.subplot(1, 1, 1)
plt.plot(0.5*fs*w/np.pi, np.abs(h), 'b')
plt.plot(cutoff, 0.5*np.sqrt(2), 'ko')
plt.axvline(cutoff, color='k')
plt.xlim(0, 0.5*fs)
plt.title("Highpass Filter")
plt.xlabel('Freq [Hz]')
plt.grid()
plt.show()


