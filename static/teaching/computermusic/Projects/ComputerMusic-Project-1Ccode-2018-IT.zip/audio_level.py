
import alsaaudio, audioop
from gpiozero import LED
from time import sleep
import datetime
from datetime import datetime

inp = alsaaudio.PCM(alsaaudio.PCM_CAPTURE,alsaaudio.PCM_NONBLOCK)

led = LED(4)
led.on()

inp.setchannels(1)
inp.setrate(8000)
inp.setformat(alsaaudio.PCM_FORMAT_S16_LE)

inp.setperiodsize(160)
f= open("/home/pi/project/audio_recording.txt","w+")
last_measurement=0
while True:
        l,data = inp.read()
        if l:
                miclvl = audioop.max(data, 2)
                current_time = datetime.now()
                if miclvl > 25000:
			if last_measurement >= 2:
				f.write("Raindrop Time: %s value: %s \r\n"  % (current_time, miclvl))
	       			print(current_time)
				print(miclvl)
				last_measurement = 0
			else: 
				last_measurement += 1
        sleep(.01)
